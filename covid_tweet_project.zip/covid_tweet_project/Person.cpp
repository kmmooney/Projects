#include "Person.h"

void Person::JDump(Json::Value* input_json_ptr) {
    this->name = ((*input_json_ptr)["name"]).asString();
    this->age = ((*input_json_ptr)["age"]).asString();
    this->city = ((*input_json_ptr)["city"]).asString();
    this->mood = ((*input_json_ptr)["mood"]).asString();
    this->personality = ((*input_json_ptr)["personality"]).asString();
    this->hadCOVID = ((*input_json_ptr)["hadCOVID"]).asString();
}

Person::Person() {
}

bool Person::JdumpT(Json::Value *input_json_ptr) {
  if ((input_json_ptr == NULL) || ((*input_json_ptr).isNull() == true) || ((*input_json_ptr).isObject() != true)) {
      return false;
    }

  if ((((*input_json_ptr)["avatar_name"]).isNull() == true) ||
      (((*input_json_ptr)["vsID"]).isNull() == true) ||
      (((*input_json_ptr)["avatar_name"]).isString() != true) ||
      (((*input_json_ptr)["vsID"]).isString() != true))
    {
      return false;
    }

  if (this->vsID == "") {
      this->vsID = ((*input_json_ptr)["vsID"]).asString();
    }

  // avatar_name can be changed (but not vsID
  this->avatar_name = ((*input_json_ptr)["avatar_name"]).asString();

  return true; // if successful
}