
#ifndef _POST_H_
#define _POST_H_

// Post.h

#include "Message.h"
#include "Person.h"
#include "tweets.h"
#include <cstring>
#include <string>
#include <vector> 

class Post
{
private:
protected:
public:
    std::string                  profile_id;
    std::string                  post_id;

    Person* author;
    Message* msg;
    std::vector<Tweets *> * twt;

    Post(void);
    Post(Person* arg_author, Message* arg_msg);
    bool Jdump(Json::Value*);
};

#endif /* _POST_H_ */

