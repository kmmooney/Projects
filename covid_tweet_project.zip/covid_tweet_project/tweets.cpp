
#include "tweets.h"

Tweets::Tweets(void) {
    this->profile_id = "";
    this->post_id = "";
    this->tweets_id = "";
    this->author = (Person*)NULL;
    this->msg = (Message*)NULL;

}

Tweets::Tweets (std::string arg_profile_id, std::string arg_post_id, std::string arg_tweets_id,
    Person* arg_author, Message* arg_msg) {
    this->profile_id = arg_profile_id;
    this->post_id = arg_post_id;
    this->tweets_id = arg_tweets_id;
    this->author = arg_author;
    this->msg = arg_msg;
}

bool Tweets::Jdump(Json::Value* input_json_ptr) {
    if ((input_json_ptr == NULL) ||
        ((*input_json_ptr).isNull() == true) ||
        ((*input_json_ptr).isObject() != true))
    {
        return false;
    }

    if ((((*input_json_ptr)["id"]).isNull() == true) ||
        (((*input_json_ptr)["from"]).isNull() == true) ||
        (((*input_json_ptr)["message"]).isNull() == true) ||
        (((*input_json_ptr)["id"]).isString() != true) ||
        (((*input_json_ptr)["from"]).isObject() != true) ||
        (((*input_json_ptr)["message"]).isString() != true))
    {
        return false;
    }

    if ((this->profile_id == "") &&
        (this->post_id == "") &&
        (this->tweets_id == ""))
    {
        char buf_profile[1024];
        bzero(buf_profile, 1024);
        char buf_post[1024];
        bzero(buf_post, 1024);
        char buf_comment[1024];
        bzero(buf_comment, 1024);

        sscanf(((*input_json_ptr)["id"].asString()).c_str(), "%[^_]_%[^_]_%s",
            buf_profile, buf_post, buf_comment);
        this->profile_id = buf_profile;
        this->post_id = buf_post;
        this->tweets_id = buf_comment;
    }

    if (this->author == NULL)
    {
        // ************************************************
        // to be completed by ecs36b_f2020 students for hw5
        // ************************************************
        this->author = new Person();
        bool rc = (this->author)->JdumpT(&((*input_json_ptr)["from"]));
        if (rc == false)
        {
            delete this->author;
            this->author = NULL;
            return false;
        }
    }

    if (this->msg == NULL)
    {
        this->msg = new Message(((*input_json_ptr)["message"]).asString());
    }


#ifdef _ECS36B_DEBUG_
    std::cout << (this->dumpJ())->toStyledString() << std::endl;
#endif /* _ECS36B_DEBUG_ */

    return true; // if successful
}
