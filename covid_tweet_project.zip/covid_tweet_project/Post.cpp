#include "Post.h"

Post::Post (void) {
  this->author = NULL;
  this->msg = NULL;
  this->twt = NULL;

  // very critical ==> portable to different platforms
  this->profile_id = "";
  this->post_id = "";
}

Post::Post (Person * arg_author, Message * arg_msg) {
  this->author = arg_author;
  this->msg = arg_msg;
  this->twt = NULL;

  // very critical ==> portable to different platforms
  this->profile_id = "";
  this->post_id = "";
}

int checkPostID (std::string id_string) {
  // check if an id string is all numerical
  
  char idstr[1024 * 128];
  bzero(idstr, 1024 * 128);
  sprintf(idstr, "%s", id_string.c_str());
  if (idstr[0] == '\0') return -1;

  char c_prof_buf[256 * 128];
  char c_post_buf[256 * 128];
  bzero(c_prof_buf, 256 * 128);
  bzero(c_post_buf, 256 * 128);
  sscanf(idstr, "%[^_]_%s", c_prof_buf, c_post_buf);

  int i;
  if ((strlen(c_prof_buf) == 0) ||
      (strlen(c_post_buf) == 0) ||
      (strlen(c_prof_buf) > 64) ||
      (strlen(c_post_buf) > 64))
    return -1;
  
  for(i = 0; i < strlen(c_prof_buf); i++)
    {
      if ((c_prof_buf[i] < '0') || (c_prof_buf[i] > '9'))
	return -1;
    }

  for(i = 0; i < strlen(c_post_buf); i++)
    {
      if ((c_post_buf[i] < '0') || (c_post_buf[i] > '9'))
	return -1;
    }
  return 0;
}

bool  Post::Jdump (Json::Value *input_json_ptr) {
  if ((input_json_ptr == NULL) ||
      ((*input_json_ptr).isNull() == true) ||
         ((*input_json_ptr).isObject() != true))
	 {
	 return false;
	 }
  

    if ((*input_json_ptr).isArray() == true) { 
      return false;
    }     
  
  // "id"
  if ((((*input_json_ptr)["id"]).isNull() != true) &&
      (((*input_json_ptr)["id"]).isString() == true) &&
      ((((*input_json_ptr)["id"]).asString()).size() > 0) &&
      ((((*input_json_ptr)["id"]).asString()).size() < 256))
    {
      if (checkPostID(((*input_json_ptr)["id"]).asString()) != 0) {
	  // HW5_ERROR_JSON_POST_NO_ID;
	  return false;
	}

      char idstr[1024];
      bzero(idstr, 1024);
      sprintf(idstr, "%s", (((*input_json_ptr)["id"]).asString()).c_str());
      if (idstr[0] != '\0')
	{
	  char c_prof_buf[256];
	  char c_post_buf[256];
	  bzero(c_prof_buf, 256);
	  bzero(c_post_buf, 256);
	  sscanf(idstr, "%[^_]_%s", c_prof_buf, c_post_buf);

	  std::string profile_id = { c_prof_buf };
	  std::string post_id = { c_post_buf };
	  
	  this->profile_id = profile_id;
	  this->post_id = post_id;
	}
      else
	{
	  std::cerr << "No Post ID presented" << std::endl;
	  // HW5_ERROR_JSON_POST_NO_ID;
	  return false;
	}
    }
  else
    {
      std::cerr << "No Post ID presented" << std::endl;
      // HW5_ERROR_JSON_POST_NO_ID;
      return false;
    }

  // "tweets"
  if ((((*input_json_ptr)["tweets"]).isNull() != true) &&
      (((*input_json_ptr)["tweets"]).isObject() == true) &&
      (((*input_json_ptr)["tweets"]["data"]).isNull() != true) &&
      (((*input_json_ptr)["tweets"]["data"]).isArray() == true))
  {
      if (this->twt == NULL)
          this->twt = new std::vector<Tweets *>();

      for (int i = 0; i < ((*input_json_ptr)["tweets"]["data"]).size(); i++)
      {
          Json::Value l_jv = (*input_json_ptr)["tweets"]["data"][i];
          Tweets* l_cmt_ptr = new Tweets();
          bool rc = l_cmt_ptr->Jdump(&(l_jv));
          if (rc == true)
          {
              // check if this is a new Tweet or not
		  std::vector<Tweets *>::iterator my_it_cm;
              int flag_cm = 0;
              for (my_it_cm = (*(this->twt)).begin();
                  my_it_cm < (*(this->twt)).end(); my_it_cm++)
              {
                  if (((*my_it_cm)->profile_id == l_cmt_ptr->profile_id) &&
                      ((*my_it_cm)->post_id == l_cmt_ptr->post_id) &&
                      ((*my_it_cm)->tweets_id == l_cmt_ptr->tweets_id))
                  {
                      flag_cm = 1;
                  }
              }

              if (flag_cm == 0)
              {
                  // new one
                  (*(this->twt)).push_back(l_cmt_ptr);
              }
              else
              {
                  // already exist
                  delete l_cmt_ptr;
              }
          }
      }
  }

  // "message"
  if ((((*input_json_ptr)["message"]).isNull() != true) &&
      (((*input_json_ptr)["message"]).isString() == true) &&
      ((((*input_json_ptr)["message"]).asString()).size() > 0) &&
      ((((*input_json_ptr)["message"]).asString()).size() < 512))
    {
      Message *l_msg_ptr = new Message((*input_json_ptr)["message"].asString());
      if (this->msg == NULL)
	this->msg = l_msg_ptr;
      else
	delete l_msg_ptr;
    }
  // "from"
  if ((((*input_json_ptr)["from"]).isNull() != true) &&
      (((*input_json_ptr)["from"]).isObject() == true))
    {
      if (this->author == NULL)
	{
	  // we assume that you can NOT change the author of a Post
	  this->author = new Person();
	  bool rc = (this->author)->JdumpT(&((*input_json_ptr)["from"]));
	  if (rc == false)
	    {
	      delete this->author;
	      this->author = NULL;
	      return false;
	    }
	}
    }

  return true; // if successful
}
