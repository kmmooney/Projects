
#ifndef _TWEETS_H_
#define _TWEETS_H_

// tweets.h

#include "Message.h"
#include "Person.h"

#include <strings.h>
#include <iostream>

class Tweets
{
private:
public:
    std::string profile_id;
    std::string post_id;
    std::string tweets_id;

    Person* author;
    Message* msg;

    Tweets(void);
    Tweets(std::string arg_profile_id, std::string arg_post_id, std::string arg_tweets_id,
        Person* arg_author, Message* arg_msg);
    bool Jdump(Json::Value*);
};

#endif /* _TWEETS_H_ */
