#pragma once

// for Json::value
#include <json/json.h>
#include <json/reader.h>
#include <json/writer.h>
#include <json/value.h>

class Person {
private:
public:
    std::string name;
    std::string age;
    std::string city;
    std::string mood;
    std::string personality;
    std::string hadCOVID;

    std::string vsID;
    std::string avatar_name;
    
    Person();
    Person(std::string, std::string);
    void JDump(Json::Value *); // used to load people
    bool JdumpT(Json::Value *); // used to load tweets info
};

/*
Positive: 
"The vaccine for Covid has now been approved for use and has 90% success rate which means after an year we have a vaccine to the global pandemic!!." ;  
"Covid-19 death rates are finally slowing down."

Negative: 
"This week, the Americas account for nearly half of all new #COVID19 cases and more than a third of all new deaths. New cases remain high in Europe, while new deaths have decreased for a 2nd week.";  
"The fast spread of covid-19 has plunged the global economy and has made millions of people lose their jobs."

Neutral: 
"Stay six feet away. Maintain social distancing to slow the spread of COVID-19."; 
"Masks can help protect you, protect others, and slow the spread, so please wear a mask!"
*/