#include <strings.h>
#include <string.h>
#include <string>
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <cstdlib>
#include <sstream>
#include <ctime>
#include <exception> 
#include <time.h>
#include <cstdio>
#include <stdlib.h>
#include <locale>

#include "Person.h"
#include "Post.h"
#include "tweets.h"
#include "Message.h"

Person loadPerson(char*);
Post loadTweets(char*);
int getTweet(std::string, std::string, std::map<std::string, std::vector<int>>);
void info(Person*);
std::string search(std::string);

std::string to_upper(std::string);

using namespace std;


int main() {
    srand(time(NULL));

    /*--------------------Loading Objects----------------------*/
    char* people_jsons[3] = {"person1.json", "person2.json", "person3.json"};
    Person user1 = loadPerson(people_jsons[0]);
    Person user2 = loadPerson(people_jsons[1]);
    Person user3 = loadPerson(people_jsons[2]);

    Post tweets = loadTweets("twitter_tweets.json");
    std::map<std::string,std::vector<int>> tweetMap;

    int i = 0;
    for(auto it: *tweets.twt) {
        std::string temp = search(it->msg->content);
        tweetMap[temp].push_back(i++);
    }
    /*--------------------------------------------------------*/
    std::string currentUser;
    Person* currentPerson;
    std::cout<<"Enter Your Name: ";
    std::cin>>currentUser;
    
    
    currentUser = to_upper(currentUser);
    
    std::cout << currentUser << std::endl;
    bool c;
    
    do {
        if(currentUser == "FELIX") {
            currentPerson = &user3;
            c = false;
        }
        else if(currentUser == "ABHAY") {
            currentPerson = &user1;
            c = false;
        }
        else if (currentUser == "KEVIN"){
            currentPerson = &user2;
            c = false;
        }
        else {
            std::cout << "Error. Incorrect name. Reenter name: ";
            std::cin >> currentUser;
            c = true;
            currentUser = to_upper(currentUser);
        }
    } while (c);

    do {
        int x;
        std::cout << "Would you like to open your feed (1), view personal info (2), or exit (3): ";
        std::cin >> x;
        if (x == 1) {
            std::cout<<"Hi "<<currentUser<<std::endl;
            std::string personalizedTweet = (*(tweets.twt))[getTweet(currentPerson->personality, currentPerson->hadCOVID, tweetMap)]->msg->content;
            std::string neutralTweet = (*(tweets.twt))[tweetMap["Neutral"][rand()%2]]->msg->content;

            std::cout<<"Your feed contains \n"<<"1." <<neutralTweet<< "\n"<<"2. "<<personalizedTweet<<std::endl;
        }
        else if (x == 2)
            info(currentPerson);
        else if (x == 3)
            break;
        else {
            std::cout << "Error. Would you like to open your feed (1), view personal info (2), or exit (3): ";
            std::cin >> x;
        }
        
    } while (true); 
}
/*--------------------Function Definitions---------------------*/
Person loadPerson(char* people_json) {    
    FILE *jf = fopen(people_json, "r");
        
    fseek(jf, 0 , SEEK_END);
    long lSize = ftell(jf);
    rewind(jf);

    char *jf_ptr = (char *) malloc(sizeof(char)*lSize);
    size_t lresult = fread(jf_ptr, 1, lSize, jf);    
    if (lresult != lSize) {
        fputs("Reading error", stderr);
        exit (-3);
    }

    Json::Value person_json;
    Json::CharReaderBuilder builder;
    Json::CharReader* reader = builder.newCharReader();
    std::string errors;
    bool parsingSuccessful = reader->parse
        (jf_ptr, jf_ptr + lSize, &person_json, &errors);
    delete reader;

    if (!parsingSuccessful) {
        std::cout << "Failed to parse the content JSON, errors:" << std::endl;
        std::cout << errors << std::endl;
    }

    Person newUser;
    newUser.JDump(&person_json);
    fclose(jf);
    return newUser;
}

Post loadTweets(char* tweets_json) {    
    FILE *jf = fopen(tweets_json, "r");
        
    fseek(jf, 0 , SEEK_END);
    long lSize = ftell(jf);
    rewind(jf);

    char *jf_ptr = (char *) malloc(sizeof(char)*lSize);
    size_t lresult = fread(jf_ptr, 1, lSize, jf);    
    if (lresult != lSize) {
        fputs("Reading error", stderr);
        exit (-3);
    }

    Json::Value tweet_json;
    Json::CharReaderBuilder builder;
    Json::CharReader* reader = builder.newCharReader();
    std::string errors;
    bool parsingSuccessful = reader->parse
        (jf_ptr, jf_ptr + lSize, &tweet_json, &errors);
    delete reader;

    if (!parsingSuccessful) {
        std::cout << "Failed to parse the content JSON, errors:" << std::endl;
        std::cout << errors << std::endl;
    }

    Post newTweets;
    newTweets.Jdump(&tweet_json);
    fclose(jf);
    return newTweets;
}



int getTweet(std::string personality, std::string hadCOVID, std::map<std::string, std::vector<int>> tweetMap) {
    if(hadCOVID == "true") {
        return tweetMap["Positive"][rand()%2];
    }
    else if(personality == "care-free") {
        return tweetMap["Negative"][rand()%2];
    }
    else if(personality == "anxious") {
        return tweetMap["Positive"][rand()%2];
    }
    else{
        return tweetMap["Neutral"][rand()%2];
    }
}

void info(Person * p) {
    std::cout << "Name: " << p-> name << std::endl;
    std::cout << "Age: " << p->age << std::endl;
    std::cout << "City: " << p->city << std::endl;
    std::cout << "Mood: " << p->mood << std::endl;
    std::cout << "Personality: " << p->personality << std::endl;
    std::cout << "Had Covid: " << p->hadCOVID << std::endl;
}

std::string to_upper(std::string s) {
    std::locale loc;
    for(std::string::size_type i = 0; i < s.length(); ++i) {
        s[i] = std::toupper(s[i], loc);
    }
    return s;
}

std::string search(string s) {
	string s1 = "deaths"; string s2 = "plunged";string s3 = "slowing";
	string s4 = "vaccine"; string s5 = "spread";
	
    std::size_t found = s.find(s1);
	if (found!=std::string::npos) return "Negative";

	found = s.find(s2);
	if (found!=std::string::npos) return "Negative";

	found = s.find(s3);
	if (found!=std::string::npos) return "Positive";

	found = s.find(s4);
	if (found!=std::string::npos) return "Positive";

	found = s.find(s5);
	if (found!=std::string::npos) return "Neutral";
}
/*---------------------------------------------------------------------*/
